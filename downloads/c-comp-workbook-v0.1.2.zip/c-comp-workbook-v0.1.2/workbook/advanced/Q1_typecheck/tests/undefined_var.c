int main() {
    int x;
    x = 1;
    return x + y;
}

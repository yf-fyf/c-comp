int main() {
    return 1 + 2 * 3 - 8 / 2;
}

# コマ15: Python 版総合演習・mycc.py 統合

この回の資料は [https://yf-fyf.github.io/c-comp/sessions/15_integrate_mycc/](https://yf-fyf.github.io/c-comp/sessions/15_integrate_mycc/) にあります。

## 今日のゴール

各回の成果を `final/mycc.py` に統合し、標準トラックの成果物を完成させる。

この回では新しい構文を追加しません。
コマ14までの実装を統合し、`final/tests/` を使って完成度を確認します。

## 実装する主な機能

- コマ1からコマ14までの `importlib` 継承チェーンをたどり、全ハンドラを
  `final/mycc.py` の単一クラスへ展開する(ファイルのコピーではない。詳細は
  [`../../final/README.md`](../../final/README.md) の「統合手順」を参照)
- `final/tests/` の全テストを実行し、落ちたテストを小さい入力に分解して修正する
- 関数の責務・変数名・コメント・重複などをコードレビューの観点で見直す
- 動作確認方法と実装上の工夫を説明できる状態に仕上げる

## 完了条件

`final/mycc.py` が単体で(他のコマのディレクトリに依存せず)起動し、
`final/tests/` が全通すること。

## 編集するファイル

- `../../final/mycc.py`

## テスト

> - `workbook/` から実行する。
> - 前回までのテストが全通していることを前提とする。
> - FAIL したら、まず最初の失敗ケースを単体で確認する。詳しい手順は [`docs/testing.md`](../../docs/testing.md) を参照。

```bash
python3 scaffold/test_runner.py
```

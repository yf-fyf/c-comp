# 進め方ガイド

> 対象: C 言語既習・コンパイラ理論未習の学習者
> ターゲット: RISC-V RV64IM（C拡張なし）
> 標準トラックは実装するコマ1〜15 の15コマが本体（準備回のコマ0 と発表会のコマ16 は別枠として扱う）

この教材では「コマ」を1回分の作業単位（資料を読む + 実装 70〜90 分程度）として使う。
週1回のペースでも、集中して一気に進めてもよい。

作るコンパイラが対象とする言語は [`language_spec.md`](./language_spec.md)（第 2 版、2026 年改訂）で
凍結してある。「この機能は書けるのか」で迷ったら、その文書が最終的な答えになる。

## 読む順序

**この文書がスタート地点である。** 上から順に進めればよい。

1. **この文書**（進め方ガイド）— 科目全体の構成と進め方を掴む。環境構築の手順はここには無い
2. [コマ0（演習環境構築）](https://yf-fyf.github.io/c-comp/sessions/00_setup/) — 環境を作る。番号のある通常回には含めない準備回で、**初回授業の開始時点で終わっているのが目標**
3. [コマ1の資料](https://yf-fyf.github.io/c-comp/sessions/01_interpreter/) — 以降は資料サイトを回ごとに読み進める
4. [`conventions.md`](./conventions.md) — 実装の約束ごと。コマ2 に入る前に一度目を通す
5. [`language_spec.md`](./language_spec.md) — 対象言語の仕様。通読せず、迷ったときに引く

途中で詰まったら [`testing.md`（テストとデバッグ）](./testing.md)、
何をどこで調べるか自体が分からなくなったら
[`README.md`（逆引き索引）](./README.md) を見る。

---

## 到達目標

| トラック | 目標 |
|---------|------|
| **標準** | Python で C サブセットコンパイラを完成させる |
| **発展**（任意） | 標準トラック（コマ1〜15）の実装完成後、選択制の発展課題（[`../advanced/`](../advanced/README.md)）に挑戦する |

**実装の完成 = コマ15 + `final/tests`（fixed17）全通、学習経路の完了 = コマ16（発表会）**、
と用語を分けている。発展課題はこの区別のうち「実装の完成」を前提にするだけで、
発表会（コマ16）を経ることを前提にしない（発表前に発展課題へ進んでよい）。
発展課題は任意であり、完了条件は各トピックの `README.md` に個別に書いてある。

---

## 環境を用意する

環境構築は **コマ0（演習環境構築）** で扱う。手順の実体はそちらにあるので、
まず [コマ0の資料](https://yf-fyf.github.io/c-comp/sessions/00_setup/)
（配布物では [`../sessions/00_setup/README.md`](../sessions/00_setup/README.md)）を読んで環境を整えること。

コマ0 で扱うのは次の3つである。

- Windows の場合の WSL 上への Ubuntu 導入
- Docker 環境（**推奨**）またはネイティブ実行の用意
- 手書き RV64 アセンブリを qemu で動かして、環境が正しいことを確かめる

Python のバージョン基準（Python 3.10 以降）を含む環境の要件は、
[コマ0 の資料](https://yf-fyf.github.io/c-comp/sessions/00_setup/)（原稿: `materials/sessions/00_setup.md`）を参照する。
この文書では要件を重ねて書かない。

イメージ名の変更やよくあるエラーは [`../docker/rv64/README.md`](../docker/rv64/README.md) を参照。

---

## 各回の進め方

1. [サイトの資料](https://yf-fyf.github.io/c-comp/sessions/) の該当する回を読む（**その回で最初にやること**）
2. `sessions/NN_xxx/README.md` の作業指示を見る
3. `sessions/NN_xxx/mycc.py` を編集する
4. テストを走らせる

```bash
python3 scaffold/test_runner.py sessions/02_arithmetic_codegen
```

**コマ3 以降は前の回の `mycc.py` を継承する。** 各回の `Codegen<NN>` は
`Codegen<NN-1>` を継承して差分だけを書く形になっているので、**順番に進め、
その回のテストを通してから次へ行く**こと。前の回に未実装が残っていると、
先の回では原因の分かりにくい失敗になる。

コマ15 の総合演習で、それまでの成果を `final/mycc.py` に統合する。
以降は引数なしの `python3 scaffold/test_runner.py` が最終成果物のテストになる。

詰まったときは [`testing.md` の症状表](./testing.md#症状から当たりをつける) を見る。
各回の完成形に相当する OCaml 版参考実装が [`../ocaml/`](../ocaml/README.md) にあるので、
自分の方針を考えたあとの確認に使える。

---

## フェーズ構成

::: note
**コマ0（準備）** — 演習環境構築。初回授業の開始時点で終わっているのが目標。番号のある通常回には含めない。
:::

| フェーズ | コマ | 内容 |
|----------|------|------|
| Phase 0 | 1 | AST 理解 |
| Phase 1 | 2〜11 | Python 版ミニコンパイラを完成させる |
| Phase 2 | 12〜15 | Python 版標準機能を完成させる |

::: note
**コマ16（発表会）** — [発表・振り返り](https://yf-fyf.github.io/c-comp/sessions/16_demo_review/)。自身の取り組みを発表する回。番号のある通常回には含めない。
:::

Phase 1 の終わり（コマ11）で「小さいが動く Python 版コンパイラ」が一度完成する。
ここで到達感を作ってから、Phase 2 で構造体などの重い機能に進む構成である。

---

## 全体の流れ

::: note
**コマ0（準備）** — 演習環境構築。初回授業の開始時点で終わっているのが目標。番号のある通常回には含めない。
:::

| コマ | テーマ | 到達目標 |
|------|--------|---------|
| 1 | AST の仕組み + インタープリターを書く | 提供 Lexer/Parser で `1+2*3` の AST を表示できる。`eval_ast()` が動く。AST を走査して意味を取り出す感覚を掴む |
| 2 | コード生成①：算術式 → RV64 アセンブリ出力 | `codegen()` が動く。`echo $?` で計算結果を確認できる |
| 3 | コード生成②：変数・代入・シンボルテーブル | `int a; a = 3; return a;` をコンパイルして実行できる |
| 4 | 制御構文①：if/else + 三項演算子 | `if(a>b) return a; else return b;` と `return a > b ? a : b;`（文の if と式の `?:` の違い）が動く |
| 5 | 制御構文②：while / for + 前置 `++`/`--` | フィボナッチ（ループ版）が `for (i = 0; i < n; ++i)` の形で動く |
| 6 | 関数呼び出し・再帰 | 再帰フィボナッチが動く |
| 7 | lvalue / rvalue の概念 + `&` / `*` | `codegen()` と `codegen_lval()` を別関数として設計・実装できる |
| 8 | 型検査の導入 | 変数の型を覚え、`char` / `int` / ポインタで読み書き命令を選べる |
| 9 | ポインタ演算とスケーリング | `malloc(sizeof(int) * 5)` で確保した領域への `a[i]` と `*(p + 2)` のポインタ演算が動く |
| 10 | 文字列リテラルと `.data` セクション | `printf("hello\n")` が動く |
| 11 | 式の走査と libc 活用 + 総合確認 | どこに書いた文字列リテラルも `.data` に出る。ミニコンパイラの完成を確認する |
| 12 | 構造体とヒープ（struct / `.` / `->` / `sizeof` / `malloc` / 連結リスト） | `struct Point` のメンバアクセスと、連結リストの構築・走査が動く |
| 13 | グローバル変数・スコープ管理 | グローバル変数とローカル変数を混在したプログラムが動く |
| 14 | 複数ファイル・前処理の概念（`#include` / `#define`） | `#include` / `#define` を含む複数 `.c` ファイルをまとめてコンパイルできる |
| 15 | Python 版総合演習・`mycc.py` 統合 | 標準トラック完成（`final/mycc.py` に統合し、`final/tests`（fixed17）全通を目安とする） |

::: note
**コマ16（発表会）** — [発表・振り返り](https://yf-fyf.github.io/c-comp/sessions/16_demo_review/)。自身の取り組みを発表する回。番号のある通常回には含めない。
:::

上の表はコマ単位の要約である。
「言語仕様のどの機能をどのコマで導入し、どのテストで検証するか」は
[`language_spec.md` の対応表](./language_spec.md#feature-map)が唯一の出典なので、
機能から回を引きたいときはそちらを見る。

各コマ終了時点でコンパイルできる具体的なプログラムは [`code_example.md`](./code_example.md) にある。

---

## コマ15 のあと

コマ15 で Python 版が完成したら、標準トラックはそこで終わる。
完成した自分の `final/mycc.py` を説明できる形に整え、そのうえで次に何をやるかを決める。

::: note
**コマ16（発表会）** — [発表・振り返り](https://yf-fyf.github.io/c-comp/sessions/16_demo_review/)。自身の取り組みを発表する回。番号のある通常回には含めない。
:::

| 行き先 | 内容 |
|--------|------|
| [`../advanced/`](../advanced/README.md) | 選択制の発展課題 28 トピック。一部はコマ15 を待たずに始められる（F0 はコマ1、B 系列はコマ6、S1 はコマ12 から）。C 移植・セルフホスト（P1）は複数回に渡る最難関トピック |

どのトピックを選ぶかは
[`../advanced/README.md` の「どこから始めるか」](../advanced/README.md#どこから始めるか)を見て決める。
発展課題に進まず、Python 版の補修・仕上げやテストの追加に時間を使うのも同じだけ正当な選択である。

---

## 参考資料

| リソース | 目的 | タイミング |
|----------|------|-----------|
| [Rui Ueyama「低レイヤを知りたい人のためのCコンパイラ作成入門」](https://www.sigbus.info/compilerbook) | コンパイラ実装の主参考書（x86-64 → RV64 置換して読む） | 発展課題（P1）挑戦時 |
| [RISC-V 仕様書 Volume I (User-Level ISA)](https://riscv.org/technical/specifications/) | 命令セット参照 | コマ2 以降 |
| [Abdulaziz Ghuloum, "An Incremental Approach to Compiler Construction"](http://scheme2006.cs.uchicago.edu/11-ghuloum.pdf) | この教材の構成の元になった論文 | 興味があれば最初に |
| [京都大学「計算機科学実験及び演習3 ソフトウェア」2015年度配布資料](https://web.archive.org/web/20150608075952/https://www.fos.kuis.kyoto-u.ac.jp/~umatani/le3b/siryo.pdf)（archive.org 保存版） | この教材の言語仕様（Core プロファイル）を設計する際に参考にした資料。対象言語 Small C の構文・型を比較した | 興味があれば |

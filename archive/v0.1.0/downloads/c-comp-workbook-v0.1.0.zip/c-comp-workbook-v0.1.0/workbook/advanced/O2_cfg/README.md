# O2: 基本ブロックとフローグラフ

この回の資料は `handout.pdf` を参照してください。

## 今日のゴール

アセンブリを**基本ブロック**に切り分け、制御の流れを辺で結んで
**フローグラフ**を作る。Graphviz で図にして目で確かめる。

前提はコマ16(完成した `final/mycc.py`)。**`mycc.py` は書き換えません**。

この回で作るフローグラフを、以降の回がそのまま使います。

| 回 | 何に使うか |
|----|-----------|
| O4 | 生存変数解析(ブロックの間で情報を伝える) |
| O6 | コピー伝播・死コード除去 |
| O7 | ブロック整列とループ回転(後方辺を探す) |

## 編集するファイル

- `cfg.py`(Step 1: `find_leaders`、Step 2: `build_blocks`、Step 3: `build_edges`)

`Block` クラス・`strip_asm`・`to_dot`(Graphviz 出力)は完成済みです。

## 動かし方

```bash
python3 ../optcc.py --passes '' ../O1_measure/bench/loop_sum.c    # 素の出力を見る
python3 golden.py                                                 # 図を書き出す
```

図は `cfg_out/` に出ます(`dot` があれば PNG も作ります)。

## テスト

```bash
python3 check.py     # リーダ・ブロック・辺の単体テスト(未実装は SKIP)
python3 golden.py    # bench/*.c のフローグラフを検証して図にする
```

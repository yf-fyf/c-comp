// int は32bitなので、最大値に1を足すと最小値に折り返す
int main() {
    int x;
    x = 2147483647;      // int の最大値
    x = x + 1;
    if (x > 0) { return 1; }        // 折り返していなければ正のまま
    if (x != -2147483648) { return 2; }

    x = -2147483648;     // int の最小値
    x = x - 1;
    if (x < 0) { return 3; }        // 折り返して正になるはず
    if (x != 2147483647) { return 4; }

    return 42;
}
